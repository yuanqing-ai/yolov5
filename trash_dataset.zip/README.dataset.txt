# e6692- > 2024-04-18 7:33pm
https://universe.roboflow.com/trashdetection-ubntx/e6692

Provided by a Roboflow user
License: CC BY 4.0

